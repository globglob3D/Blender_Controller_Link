"""Unit tests SDL2.

This package contains the unit tests for SDL2.
"""
